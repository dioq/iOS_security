//
//  CheckViewController.m
//  SecurityStudy
//
//  Created by Dio Brand on 2023/4/11.
//

#import "BaseViewController.h"
#import "MyPtrace.h"
#import <mach-o/dyld.h>
#import <sys/sysctl.h>
#import "JailbreakTool.h"

@interface BaseViewController ()<UITextViewDelegate>
{
    NSString *homeDir;
    NSString *libDir;
    NSString *bundlePath;
    NSString *unknowUUID;
}
@property (weak, nonatomic) IBOutlet UITextView *show;
@property(nonatomic, strong)NSFileManager *fileManager;
@property(nonatomic,copy)NSString *filePath;

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"基本防护";
    self.show.delegate = self;
    
    unknowUUID = @"XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
    
    _fileManager = [NSFileManager defaultManager];
    // 获取沙盒根目录路径
    homeDir = NSHomeDirectory();
    NSLog(@"homeDir:\n%@",homeDir);
    //获取Library的目录路径
    libDir = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask,YES) firstObject];
    NSLog(@"libDir:\n%@",libDir);
    bundlePath = [[NSBundle mainBundle] bundlePath];
    NSLog(@"bundlePath:\n%@",bundlePath);
    
//    [self save_image_list];
}

-(void)save_image_list {
    NSMutableArray *mutableArr = [[NSMutableArray alloc] init];
    uint32_t count = _dyld_image_count();
    // 创建一个正则
    NSString *pattern = @"[0-9A-Z]{8}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[-][0-9A-Z]{12}";
    for (uint32_t i = 0 ; i < count; ++i) {
        const char *image_name = _dyld_get_image_name(i);
//        printf("%s\n",name);
        NSString *image_name2 = [NSString stringWithUTF8String:image_name];
        NSError *error = NULL;
        
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
        if(error) {
            NSLog(@"%@",[error localizedFailureReason]);
            return;
        }
        NSUInteger count = [regex numberOfMatchesInString:image_name2 options:0 range:NSMakeRange(0,image_name2.length)];
        if(count > 0) {
            NSString *image_name3 = [regex stringByReplacingMatchesInString:image_name2 options:0 range:NSMakeRange(0,image_name2.length) withTemplate:unknowUUID];
//            NSLog(@"image_name3: %@",image_name3);
            [mutableArr addObject:image_name3];
        }else {
            [mutableArr addObject:image_name2];
        }
    }
    
//    [self printArray:[mutableArr copy]];
    
    NSError *error;
    NSData *image_set_data = [NSJSONSerialization dataWithJSONObject:[mutableArr copy] options:NSJSONWritingPrettyPrinted error:&error];
    NSLog(@"data.length:%lu",image_set_data.length);
    if (error) {
        NSLog(@"convert json error:\n%@",[error localizedFailureReason]);
    }
    
    
    NSString *newDirName = @"MyPrivate";
    NSString *newDirPath = [NSString stringWithFormat:@"%@/%@",libDir, newDirName];
    //     如果文件所在的 目录不存在 是无法写入数据的,需要先创建对应的目录
    if (![_fileManager fileExistsAtPath:newDirPath]) {
        NSError *error;
        [_fileManager createDirectoryAtPath:newDirPath withIntermediateDirectories:YES attributes:nil error:&error];
        if (error) {
            NSLog(@"%@",error);
            return;
        }
    }
    
    // 要写入的文件名字 和 绝对路径
    NSString *fileName = @"imagelist.dat";
    _filePath = [NSString stringWithFormat:@"%@/%@",newDirPath,fileName];
    
    [image_set_data writeToFile:_filePath options:NSDataWritingAtomic error:&error];
    if (error) {
        NSLog(@"%@",error);
        return;
    }
}

//封装遍历数组的函数
void array_display(id array)
{
    for (int i = 0 ; i < [array count]; i++) {
        id temp = [array objectAtIndex:i];
        NSLog(@"%@", temp);
    }
}

- (IBAction)ptrace_act:(UIButton *)sender {
    //app反调试防护,运行这行代码后就不再允许其他进程附加上了
    ptrace(PT_DENY_ATTACH, 0, 0, 0);
}

- (BOOL)isDebug{
    int name[4];//里面存放字节码
    name[0] = CTL_KERN;//内核查询
    name[1] = KERN_PROC;//查询进程
    name[2] = KERN_PROC_PID;//传递的参数是进程ID
    name[3] = getpid();//PID 进程ID
    
    struct kinfo_proc info;//查询到的结果放到此结构体
    
    size_t info_size = sizeof(info);
    
    //调试信息
    sysctl(name, sizeof(name)/sizeof(*name), &info, &info_size, 0, 0);
    
    //info.kp_proc.p_flag 第12位若为1则存在调试
    
    return ((info.kp_proc.p_flag & P_TRACED) !=0);
}
- (IBAction)darwin_act:(UIButton *)sender {
    if([self isDebug]){
        [self.show setText:@"正在被调试"];
    }else{
        [self.show setText:@"没有被其他程序调试"];
    }
}

- (IBAction)dylib_act:(UIButton *)sender {
    NSMutableDictionary *tipDict = [NSMutableDictionary dictionary];
    // 待检测动态库
    NSArray *dylibArr = @[
        @"/Library/MobileSubstrate/MobileSubstrate.dylib",
        @"/Library/MobileSubstrate/DynamicLibraries",
        @"substitute",
        @"frida"
    ];
    
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0 ; i < count; ++i) {
        const char *name = _dyld_get_image_name(i);
        printf("%s\n",name);
        NSString *name2 = [NSString stringWithUTF8String:name];
        for (NSString *symbol_name in dylibArr) {
            if ([name2 containsString:symbol_name]) {
                [tipDict setValue:@"可疑动态库" forKey:name2];
            }
        }
    }
    [self showLog:tipDict];
}

-(NSArray *)get_image_whilelist {
    NSString *filepath = [[NSBundle mainBundle]pathForResource:@"imagelist" ofType:@"dat"];
    NSData *data = [NSData dataWithContentsOfFile:filepath];
    NSLog(@"data.length:%lu",data.length);
    NSError *error;
    NSArray *image_whilelist = [NSJSONSerialization JSONObjectWithData:data
                                                        options:NSJSONReadingMutableContainers
                                                          error:&error];
    if(error) {
        NSLog(@"convert json error:\n%@",[error localizedFailureReason]);
        return nil;
    }
    
    // 创建一个正则
    NSString *pattern = @"[0-9A-Z]{8}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[-][0-9A-Z]{4}[-][0-9A-Z]{12}";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
    if(error) {
        NSLog(@"%@",[error localizedFailureReason]);
        return nil;
    }
    //仅取出第一条匹配记录
    NSTextCheckingResult *firstResult = [regex firstMatchInString:bundlePath options:0 range:NSMakeRange(0, [bundlePath length])];
    NSString *path_uuid = @"";
    if (firstResult) {
        path_uuid = [bundlePath substringWithRange:firstResult.range];
        NSLog(@"path_uuid:%@", path_uuid);
    }
    
    NSMutableArray *image_whilelist2 = [[NSMutableArray alloc] init];
    for (NSString *image_name in image_whilelist) {
        if([image_name containsString:unknowUUID]) {
            NSMutableString *image_name_tmp = [[NSMutableString alloc] initWithString:image_name];
            NSString *image_name_tmp2 = [image_name_tmp stringByReplacingOccurrencesOfString:unknowUUID withString:path_uuid];
            [image_whilelist2 addObject:image_name_tmp2];
        }else {
            [image_whilelist2 addObject:image_name];
        }
    }
    
    return [image_whilelist2 copy];
}

-(void)printArray:(NSArray *)arr {
    for (NSString *item in arr) {
        NSLog(@"%@",item);
    }
}

- (IBAction)image_whitelist:(UIButton *)sender {
    NSArray *image_whilelist = [self get_image_whilelist];
//    NSLog(@"============= 白名单里的动态库 ==============");
//    [self printArray:image_whilelist];
    //    NSArray *setToArray = [image_whilelist allObjects];
    //    array_display(setToArray);
    
    
    // 获取所有当前加载的动态库
    NSMutableArray *image_list_current = [[NSMutableArray alloc] init];
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0 ; i < count; ++i) {
        const char *image_name = _dyld_get_image_name(i);
        //        printf("%s\n",image_name);
        NSString *image_name2 = [NSString stringWithUTF8String:image_name];
        [image_list_current addObject:image_name2];
    }
    NSArray *image_list_current2 = [image_list_current copy];
//    NSLog(@"============= 当前进程时的动态库 ==============");
//    [self printArray:image_list_current2];
    NSMutableDictionary *tipDict = [NSMutableDictionary dictionary];
    for (NSString *image_name in image_list_current2) {
        if(![image_whilelist containsObject:image_name]) {
            [tipDict setValue:@"没在动态库白名单中" forKey:image_name];
        }
    }

    if([[tipDict allValues] count]) {
        [self showLog:tipDict];
    }else {
        NSString *tip;
        tip = @"当前加载的所有动态库,与白名单一致";
        [self showTip:tip];
    }
}


- (IBAction)files_check_act:(UIButton *)sender {
    NSMutableDictionary *tipDict = [NSMutableDictionary dictionary];
    NSArray *fileArr = @[@"/usr/lib/frida/frida-agent.dylib"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    for (NSString *filePath in fileArr) {
        if ([fileManager fileExistsAtPath:filePath]) {
            [tipDict setValue:@"检测到了" forKey:filePath];
        }else{
            [tipDict setValue:@"没检测到" forKey:filePath];
        }
    }
    [self showLog:tipDict];
}

- (IBAction)jailbreak_check:(UIButton *)sender {
    BOOL isOr = [[JailbreakTool sharedManager] isJailbroken];
    NSString *result = nil;
    if (isOr) {
        result = @"已经越狱";
    }else{
        result = @"没有越狱";
    }
    [self showTip:result];
}

-(void)showTip:(NSString * _Nonnull)tip {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.show setText:tip];
        NSLog(@"%@",tip);
    });
}

-(void)showLog:(NSDictionary * _Nonnull)tipDict {
    NSError *err;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:tipDict options:NSJSONWritingPrettyPrinted error:&err];
    
    if (err) {
        [self showTip:[err localizedFailureReason]];
    }else{
        NSString *logStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        [self showTip:logStr];
    }
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [self.view endEditing:YES];
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

@end
